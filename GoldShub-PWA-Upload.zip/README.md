# GoldShub PWA
Progressive Web App for GoldShub.com.

Files:
- index.html
- manifest.json
- sw.js
- icons/icon-192.png
- icons/icon-512.png

After uploading these files to GitHub, enable GitHub Pages from Settings → Pages → Deploy from branch → main → / (root).
